<?php
phpinfo() ;
?>