<?php
define('SAE_MYSQL_USER', '');
define('SAE_MYSQL_PASS', '');
define('SAE_MYSQL_HOST_M', '127.0.0.1');
define('SAE_MYSQL_HOST_S', '127.0.0.1');
define('SAE_MYSQL_PORT', '3306');

// document root
$_SERVER['DOCUMENT_ROOT'] = 'F:\windows\wwwroot' ;

define('HTTP_PORT','80') ;
define('HTTPS_PORT','443') ;
define('REDIS_HOST','127.0.0.1') ;
define('REDIS_PORT','6379') ;
?>